You need to copy, or symlink, the "lib" folder from Core2 to Core4.

Also, the "oesjs-core4a" folder requires copies/symlinks of/to the following files from OES/doc/js/Core2/OESjs-Core2:

* index.js
* OES-Activities.js
* OES-Foundation.js
* simulator.js
* simulatorUI.js

and possibly the following files from Core3/OESjs-Core3:

* OES-ProcessingNetworks.js