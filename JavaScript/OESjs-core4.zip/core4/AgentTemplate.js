class Agent extends aGENT {
  constructor({ id, name, attr}) {
    super({id, name});
    this.attr = attr;
  }
  onReceive( message, roundBased) {
    switch (message.type) {
    case "LureMessage":
      //...
      break;
    }
    // return [resultingStateChanges, resultingFutureEvents];
  }
  onPerceive( perceptionEvt, roundBased) {
    switch (perceptionEvt.constructor.name) {
    case "PerceiveInDelivery":
      // ...
      break;
    }
    // return [resultingStateChanges, resultingFutureEvents];
  }
  onTimeEvent( timeEvt) {
    switch (timeEvt.constructor.name) {
    case "EndOfWeek":
      // ...
      break;
    }
    // return [resultingStateChanges, resultingFutureEvents];
  }
}
