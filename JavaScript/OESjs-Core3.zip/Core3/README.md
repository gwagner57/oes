You need to copy, or symlink, the "lib" folder from Core2 to Core3.

Also, the Core3 folder requires copies/symlinks of/to the following files from the folder Core2/framework:

* index.js
* OES-Activities.js
* OES-Foundation.js
* simulator.js
* simulatorUI.js
