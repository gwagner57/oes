class WheelLoader extends oBJECT {
  constructor({ id, name, status}) {
    super( id, name);
    this.status = status;
  }
}
WheelLoader.labels = {"status":"st", "activityState":"act"};
